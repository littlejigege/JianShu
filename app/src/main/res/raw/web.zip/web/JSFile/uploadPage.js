function doResponse(JSONObject) {
    var device = document.getElementById("deviceName");//获取填装设备名称的容器
    var AVersion = document.getElementById("AndroidVersion");//获取填装安卓版本的容器
    var MemoryTd = document.getElementById("deviceMemory");//获取填装手机容量的容器
    var percent = (JSONObject.availableSize / JSONObject.totalSize) * 100;//计算背景中可用空间颜色占的百分比
    var restPercent = 100.0 - percent;//获取背景中已用空间颜色的百分比
    var percentString = percent.toFixed(2);//百分比转为两位小数
    var restPercentString = restPercent.toFixed(2);
    var ASize = JSONObject.availableSize; //获取反馈的可用空间信息
    var TSize = JSONObject.totalSize; //获取反馈得到的总空间的信息
    var ASizeStr;
    var TSizeStr;
    var KB, MB, GB;
    KB = 1024;
    MB = KB * 1024;
    GB = MB * 1024;  //以下进行比特单位的添加。
    if (ASize < KB) {
        ASizeStr = ASizeNum.toFixed(2) + " B";
    }
    else if (ASize >= KB && ASize < MB) {
        ASize /= KB;
        ASizeStr = ASize.toFixed(2) + " KB";
    }
    else if (ASize >= MB && ASize < GB) {
        ASize /= MB;
        ASizeStr = ASizeNum.toFixed(2) + " MB";
    }
    else {
        ASize /= GB;
        ASizeStr = ASize.toFixed(2) + " GB";
    }
    if (TSize < KB) {
        ASizeStr = TSize.toFixed(2) + " B";
    }
    else if (TSize >= KB && TSize < MB) {
        TSize /= KB;
        TSizeStr = TSize.toFixed(2) + " KB";
    }
    else if (TSize >= MB && TSize < GB) {
        TSizeNum /= MB;
        TSizeStr = TSize.toFixed(2) + " MB";
    }
    else {
        TSize /= GB;
        TSizeStr = TSize.toFixed(2) + " GB";
    }
    MemoryTd.innerHTML = ASizeStr + '可用\/' + TSizeStr;//添加描述 可用空间/总空间
    MemoryTd.style.backgroundImage = "linear-gradient(90deg,#1598b6 " + percentString + "%,#7dc5d4 " + restPercentString + "%)";//利用渐变设置背景颜色。
    device.innerHTML = JSONObject.model; //填充手机名称内容
    AVersion.innerHTML = JSONObject.androidVersion;//填充安卓版本内容
    loading.style.display = "none";
}

window.onload = function () {
    let loading = document.getElementById("loading");
    loading.style.display = "block";
    var request = new HttpRequester(UResourseL.getDeviceInfo, doResponse);//进行获取手机信息的http请求
    request.httpRequest();
    let mainContainer = document.getElementById("mainContainer");
    mainContainer.ondragover = function (event) {
        event.preventDefault();
        this.style.border ="1px solid blue";
    };
    mainContainer.ondragenter = function (event) {
        event.preventDefault();
        this.style.border ="1px solid blue";
    };
    mainContainer.ondragleave = function (event) {
        event.preventDefault();
        this.removeAttribute("style");
    };
    mainContainer.ondrop = function (event) {
        event.preventDefault();
        this.removeAttribute("style");
        let file = event.dataTransfer.files[0];
        let httpPoster = new XMLHttpRequest();
        let fr = new FormData();
        let tMFrame = document.getElementById("transferMessageFrame");
        let TM = document.getElementById("transferMessage");
        let Message = document.getElementById("isSuccess");
        tMFrame.style.display = "block";
        fr.append("file", file);
        httpPoster.open("POST", UResourseL.hostName + "/upload?fileName=" + file.name, true);
        httpPoster.send(fr);
        httpPoster.onreadystatechange = function () {
            if (httpPoster.readyState == 4 && httpPoster.status == 200) {
                let flag = httpPoster.responseText;
                let fallBackMess = JSON.parse(flag);
                if(fallBackMess.code="1") {
                    TM.style.display="none";
                    Message.innerHTML = "上传成功";
                }
                else {
                    TM.style.display = "none";
                    Message.innerHTML="上传失败";
                }
                setTimeout(function(){
                    tMFrame.style.display="none";
                    TM.style.display="block";
                    Message.innerHTML = "上传中";
                },2500);
            }
        }
    }
}
function chooseFile(){
    let chooseFile = document.getElementById("uploadFile");
    chooseFile.click();
}
function file_open(event){
    let file = event.currentTarget.files[0];
    let httpPoster = new XMLHttpRequest();
    let fr = new FormData();
    let tMFrame = document.getElementById("transferMessageFrame");
    let TM = document.getElementById("transferMessage");
    let Message = document.getElementById("isSuccess");
    tMFrame.style.display = "block";
    fr.append("file", file);
    httpPoster.open("POST", UResourseL.hostName + "/upload?fileName=" + file.name, true);
    httpPoster.send(fr);
    httpPoster.onreadystatechange = function () {
        if (httpPoster.readyState == 4 && httpPoster.status == 200) {
            let flag = httpPoster.responseText;
            let fallBackMess = JSON.parse(flag);
            if(fallBackMess.code="1") TM.style.display="none";
            Message.innerHTML = "上传成功";
            setTimeout(function(){
                tMFrame.style.display="none";
                TM.style.display="block";
                Message.innerHTML = "上传中";
            },2500);
        }
    }
}

