function fileDownload() {
    var selectedGroup = document.getElementsByTagName("img");
    var hiddenBlock = document.getElementById("hiddenBlock");
    var selectedNum = document.getElementById("selectedNum");
    let selectAll = document.getElementById("selectAll");
    var totalURL = "";
    var downloadLink = document.createElement("a");
    for (var i = 0; i < selectedGroup.length; i++) {
        if (selectedGroup[i].id !== "selectAll") {
            if (selectedGroup[i].getAttribute("style") !== null) {
                var Nrow = selectedGroup[i].id.substring(selectedGroup[i].id.indexOf('_') + 1, selectedGroup[i].id.length);//获取行数
                var fileLinker = document.getElementById("fileLinker_" + Nrow);//获取对应行的文件链接
                var isDirectory = document.getElementById("isDirectory_" + Nrow);
                if (isDirectory === null) {
                    totalURL += fileLinker.href.substring(fileLinker.href.indexOf('=') + 1, fileLinker.href.lastIndexOf('&')) + '|';
                }
                else {
                    totalURL += fileLinker.href.substring(fileLinker.href.indexOf("=") + 1, fileLinker.href.length) + '|';
                }
                selectedGroup[i].removeAttribute("style");
            }
        }
    }
    if(selectAll.getAttribute("style")!==null) selectAll.removeAttribute("style");
    totalURL = totalURL.substring(0, totalURL.length - 1);
    downloadLink.href = UResourseL.download + totalURL;
    $(document.body).append(downloadLink);
    downloadLink.click();
    document.body.removeChild(document.body.lastChild);
    hiddenBlock.style.display = "none";
    selectedNum.innerHTML = '';
}
