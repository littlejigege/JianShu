function doResponse(JSONObject) {
    var KB = 1024;
    var MB = KB * 1024;
    var GB = MB * 1024;
    var fileList = document.getElementById("fileList");
    let loading = document.getElementById("loading");
    for (var i = 0; i < JSONObject.mFile.length; i++) {
        if (JSONObject.mFile[i].path.charAt(JSONObject.mFile[i].path.lastIndexOf('/') + 1) == '.') continue;//去掉以.开头的文件夹
        var e = document.getElementById("fileList");    //获取装载文件信息的容器
        var node1 = document.createElement("tr");//建立行单元
        var arrayNode = new Array(6);//建立6个列单元
        for (var k = 0; k < arrayNode.length; k++) {
            arrayNode[k] = document.createElement("td");
        }
        e.appendChild(node1);
        node1.id = 'tr_' + i;
        e = document.getElementById("tr_" + i);//获取指定的行单元
        for (var j = 0; j < arrayNode.length; j++) {//将列单元放入行单元中。
            e.appendChild(arrayNode[j]);
        }
        var imgDot = document.createElement("img");//产生img单元，用来容纳选中图片.
        imgDot.src = "images/headerPicture/grayDot.png";
        imgDot.className = "adjustDot";//设置img的class
        imgDot.id = String(i);
        imgDot.onclick = function () {//设置img的点击事件。点击进行图片的切换
            abort();
            var flag = (this.getAttribute("style") === null);
            var hiddenBlock = document.getElementById("hiddenBlock");
            var selectedNum = document.getElementById("selectedNum");
            if (flag) {
                this.style.backgroundImage = "url('images/blueWhiteDot.png')";
                if (selectedNum.innerHTML == '') selectedNum.innerHTML = '1';
                else selectedNum.innerHTML = String(1 + parseInt(selectedNum.innerHTML));
                hiddenBlock.style.display = "block";
                console.log(hiddenBlock.style.display);
            }
            else if (flag == false) {
                this.removeAttribute("style");
                if (selectedNum.innerHTML == '1') {
                    hiddenBlock.style.display = "none";
                    selectedNum.innerHTML = '';
                }
                else if (selectedNum.innerHTML != '')
                    selectedNum.innerHTML = String(parseInt(selectedNum.innerHTML) - 1);
                var selectAll = document.getElementById("selectAll");
                selectAll.removeAttribute("style");//当去掉背景图片时全选按钮变为未选。
            }
        }
        if (JSONObject.mFile[i].isDirectory) {//对文件夹进行添加文件夹图片
            var imgFileFolder = document.createElement("img");
            imgFileFolder.src = "images/fileFolder.png";
            imgFileFolder.className = "folderImg";
            arrayNode[1].appendChild(imgFileFolder);
        }
        //以下进行列单元内容的填充。
        arrayNode[0].appendChild(imgDot);
        //以下进行文件类型的识别
        var doctype = JSONObject.mFile[i].path.substring(JSONObject.mFile[i].path.lastIndexOf('.') + 1, JSONObject.mFile[i].path.length);
        var img = document.createElement("img");
        switch (doctype) {
            case "doc":
            case "docx":
                img.src = "images/docx.png";
                break;
            case "pdf":
                img.src = "images/PDF.png";
                break;
            case "txt":
                img.src = "images/TXT.png";
                break;
            case "xls":
            case "xlsx":
                img.src = "images/xlsx.png";
                break;
            case "png":
            case "jpg":
            case "jpeg":
                img.src = "images/pic.png";
                break;
        }
        arrayNode[1].appendChild(img);
        //以下进行文件夹进入操作设置
        var FFolderLink = document.createElement("a");
        FFolderLink.className = "fileLinker";
        FFolderLink.id = "fileLinker_" + i;
        if (JSONObject.mFile[i].isDirectory) {
            FFolderLink.innerHTML = JSONObject.mFile[i].path.substring(JSONObject.mFile[i].path.lastIndexOf('/') + 1, JSONObject.mFile[i].path.length);
            FFolderLink.href = UResourseL.getFile + JSONObject.mFile[i].path;
            FFolderLink.onclick = function (event) {
                event.preventDefault();
                abort();
                var fileList1 = document.getElementById("fileList");
                var colGroup = new Array(6);
                //以下进行更改显示中的路径的操作
                var showingRoute = document.getElementById("route");
                showingRoute.innerHTML = showingRoute.innerHTML + '/' + this.innerHTML;
                var backWard = document.getElementById("backWard");
                backWard.onclick = function () {
                    var Route = document.getElementById("route");
                    var fileTable = document.getElementById("fileList");
                    var a = Route.innerHTML.indexOf('/');
                    var b = Route.innerHTML;
                    var backWardURL = UResourseL.getAllFile + b.substring(a + 1, b.lastIndexOf('/'));
                    if (a != -1) {
                        fileTable.innerHTML = "";
                        var colG = new Array(6);
                        for (var i = 0; i < colG.length; i++) {
                            colG[i] = document.createElement("col");
                            colG[i].className = "space" + (i + 1);
                            fileTable.appendChild(colGroup[i]);
                        }
                        Route.innerHTML = b.substring(0, b.lastIndexOf('/'));
                        var XMLHttp = new HttpRequester(backWardURL, doResponse);
                        XMLHttp.httpRequest();
                    }
                }
                fileList1.innerHTML = "";
                for (var z = 0; z < colGroup.length; z++) {
                    colGroup[z] = document.createElement("col");
                    colGroup[z].className = "space" + (z + 1);
                    fileList1.appendChild(colGroup[z]);
                }
                let loading = document.getElementById("loading");
                loading.style.display = "block";
                var request = new HttpRequester(this.href, doResponse);
                request.httpRequest();
            }
            arrayNode[2].appendChild(FFolderLink);
        }
        else {
            let label =document.createElement("LABEL");
            FFolderLink.innerHTML = JSONObject.mFile[i].path.substring(JSONObject.mFile[i].path.lastIndexOf('/') + 1, JSONObject.mFile[i].path.length);
            FFolderLink.href = UResourseL.download + encodeURIComponent(JSONObject.mFile[i].path) + "&preview=true";
            FFolderLink.onclick =function (event){
                event.preventDefault();
            }
            label.setAttribute("for",String(i));
            label.appendChild(FFolderLink);
            arrayNode[2].appendChild(label);
        }
        arrayNode[3].innerHTML = JSONObject.mFile[i].lastModify;
        var docSizeNum = JSONObject.mFile[i].size;
        var docSizeStr;
        //以下进行比特单位的添加
        if (docSizeNum < KB) {
            docSizeStr = docSizeNum.toFixed(2) + " B";
        }
        else if (docSizeNum >= KB && docSizeNum < MB) {
            docSizeNum /= KB;
            docSizeStr = docSizeNum.toFixed(2) + " KB";
        }
        else if (docSizeNum >= MB && docSizeNum < GB) {
            docSizeNum /= MB;
            docSizeStr = docSizeNum.toFixed(2) + " MB";
        }
        else {
            docSizeNum /= GB;
            docSizeStr = docSizeNum.toFixed(2) + " GB";
        }
        if (!JSONObject.mFile[i].isDirectory) arrayNode[4].innerHTML = docSizeStr;//文件夹省略大小
        arrayNode[5].innerHTML = JSONObject.mFile[i].isDirectory ? '文件夹' : '文件';
        if (JSONObject.mFile[i].isDirectory) {
        arrayNode[5].id = "isDirectory_" + i;
        }
         else {
            arrayNode[5].id = "isFile_" + i;
        }
    }
    if(fileList.rows.length==0) fileList.innerHTML = "空空如也哦";
    loading.style.display="none";
}

function refreshAF() {
    abort();
    let hiddenBlock = document.getElementById("hiddenBlock");
    let selectedNum = document.getElementById("selectedNum");
    hiddenBlock.style.display="none";
    selectedNum.innerHTML = "";
    var route = document.getElementById("route");
    var path;
    if (route.innerHTML.indexOf('/') !== -1) {
        path = UResourseL.getAllFile+route.innerHTML.substring(route.innerHTML.indexOf('/') + 1, route.innerHTML.length);
    }
    else path=UResourseL.getAllFile;
    refresh(path,doResponse);
}

function afterCNBtnClick(){
    let inputFolderName = document.getElementById("inputNFolderName");
    inputFolderName.style.display = "block";
}

function createNewFolder(){
    let inputFolderName = document.getElementById("inputNFolderName");
    inputFolderName.style.display = "none";
    let route = document.getElementById("route");
    let a = route.innerHTML.indexOf("/");
    let path;
    let fileList = document.getElementById("fileList");
    let tdGroup = new Array(6);
    let row = document.createElement("tr");
    let imgs = document.getElementsByClassName("adjustDot");
    row.name = "newFolder";
    let rowNum =imgs[imgs.length-1].id.substring(imgs[imgs.length-1].id.indexOf("_"),imgs[imgs.length-1].id.length);
    row.id = "tr_"+(parseInt(rowNum)+1);
    let inputText = document.getElementById("newFolderName");
    let name = inputText.value;
    let img = document.createElement("img");
    img.src = "images/headerPicture/grayDot.png";
    img.name = "newFolder";
    img.className = "adjustDot";
    img.id = String(parseInt(rowNum+1));
    img.onclick = function () {//设置img的点击事件。点击进行图片的切换
        var flag = (this.getAttribute("style") === null);
        var hiddenBlock = document.getElementById("hiddenBlock");
        var selectedNum = document.getElementById("selectedNum");
        if (flag) {
            this.style.backgroundImage = "url('images/blueWhiteDot.png')";
            if (selectedNum.innerHTML == '') selectedNum.innerHTML = '1';
            else selectedNum.innerHTML = String(1 + parseInt(selectedNum.innerHTML));
            hiddenBlock.style.display = "block";
            console.log(hiddenBlock.style.display);
        }
        else if (flag == false) {
            this.removeAttribute("style");
            if (selectedNum.innerHTML == '1') {
                hiddenBlock.style.display = "none";
                selectedNum.innerHTML = '';
            }
            else if (selectedNum.innerHTML != '')
                selectedNum.innerHTML = String(parseInt(selectedNum.innerHTML) - 1);
            var selectAll = document.getElementById("selectAll");
            selectAll.removeAttribute("style");//当去掉背景图片时全选按钮变为未选。
        }
    }
    let FFolder = document.createElement("img");
    FFolder.className = "folderImg";
    FFolder.src = "images/fileFolder.png";
    FFolder.className ="folderImg";
    if(a===-1){
        path = "/storage/emulated/0/";
    }
    else{
        path="/storage/emulated/0"+route.innerHTML.substring(route.innerHTML.indexOf('/'),route.innerHTML.length);
    }
    let link = document.createElement("a");
    link.id="fileLinker_"+String(parseInt(rowNum)+1);
    link.innerHTML = name;
    link.className = "fileLinker";
    link.href = UResourseL.getFile+path+'/'+name;
    link.onclick = function (event) {
        event.preventDefault();
        var fileList1 = document.getElementById("fileList");
        var colGroup = new Array(6);
        //以下进行更改显示中的路径的操作
        var showingRoute = document.getElementById("route");
        showingRoute.innerHTML = showingRoute.innerHTML + '/' + this.innerHTML;
        var backWard = document.getElementById("backWard");
        backWard.onclick = function () {
            var Route = document.getElementById("route");
            var fileTable = document.getElementById("fileList");
            var a = Route.innerHTML.indexOf('/');
            var b = Route.innerHTML;
            var backWardURL = UResourseL.getAllFile + b.substring(a + 1, b.lastIndexOf('/'));
            if (a != -1) {
                fileTable.innerHTML = "";
                var colG = new Array(6);
                for (var i = 0; i < colG.length; i++) {
                    colG[i] = document.createElement("col");
                    colG[i].className = "space" + (i + 1);
                    fileTable.appendChild(colGroup[i]);
                }
                Route.innerHTML = b.substring(0, b.lastIndexOf('/'));
                let loading = document.getElementById("loading");
                loading.style.display = "block";
                var XMLHttp = new HttpRequester(backWardURL, doResponse);
                XMLHttp.httpRequest();
            }
        }
        fileList1.innerHTML = "";
        for (var z = 0; z < colGroup.length; z++) {
            colGroup[z] = document.createElement("col");
            colGroup[z].className = "space" + (z + 1);
            fileList1.appendChild(colGroup[z]);
        }
        let loading = document.getElementById("loading");
        loading.style.display = "block";
        var request = new HttpRequester(this.href, doResponse);
        request.httpRequest();
    }
    for(let i=0;i<tdGroup.length;i++){
        tdGroup[i]=document.createElement("td");
        row.appendChild(tdGroup[i]);
    }
    let httpR = new HttpRequester(UResourseL.createNewFolder+path+'/'+name,function(JSONObject){
        console.log("success");
    });
    httpR.httpRequest();
    tdGroup[0].appendChild(img);
    tdGroup[1].appendChild(FFolder);
    tdGroup[2].appendChild(link);
    let now = new Date();
    tdGroup[3].innerHTML = now.toLocaleDateString();
    tdGroup[4].innerHTML="";
    tdGroup[5].innerHTML="文件夹";
    fileList.appendChild(row);
    let fileListContainer = document.getElementById("fileListContainer");
    fileList.scrollIntoView();
}

function abort(){
    let inputFileName = document.getElementById("inputNFolderName");
    inputFileName.style.display = "none";
}

window.onload = function () {
    let loading = document.getElementById("loading");
    var request = new HttpRequester(UResourseL.getAllFile, doResponse);//进行http请求
    request.httpRequest();
    loading.style.display="block";
    let mainContainer = document.getElementById("mainContainer");
    mainContainer.ondragover = function (event) {
        event.preventDefault();
        this.style.border ="1px solid blue";
    };
    mainContainer.ondragenter = function (event) {
        event.preventDefault();
        this.style.border ="1px solid blue";
    };
    mainContainer.ondragleave = function (event) {
        event.preventDefault();
        this.removeAttribute("style");
    };
    mainContainer.ondrop = function (event) {
        event.preventDefault();
        this.removeAttribute("style");
        let file = event.dataTransfer.files[0];
        let httpPoster = new XMLHttpRequest();
        let fr = new FormData();
        let tMFrame = document.getElementById("transferMessageFrame");
        let TM = document.getElementById("transferMessage");
        let Message = document.getElementById("isSuccess");
        let route = document.getElementById("route");
        let a = route.innerHTML.indexOf("/");
        let savePath;
        if(a!=-1){
            savePath=encodeURIComponent("/storage/emulated/0/"+route.innerHTML.substring(route.innerHTML.indexOf('/'),route.innerHTML.length));
        }
        else{
            savePath=encodeURIComponent("/storage/emulated/0/");
        }
        tMFrame.style.display = "block";
        fr.append("file", file);
        httpPoster.open("POST", UResourseL.hostName + "/upload?savePath="+savePath+"&fileName=" + file.name, true);
        httpPoster.send(fr);
        httpPoster.onreadystatechange = function () {
            if (httpPoster.readyState == 4 && httpPoster.status == 200) {
                let flag = httpPoster.responseText;
                let fallBackMess = JSON.parse(flag);
                if(fallBackMess.code="1") {
                    TM.style.display="none";
                    Message.innerHTML = "上传成功";
                    refreshAF();
                }
                else {
                    TM.style.display = "none";
                    Message.innerHTML="上传失败";
                }
                setTimeout(function(){
                    tMFrame.style.display="none";
                    TM.style.display="block";
                    Message.innerHTML = "上传中";
                },2500);
            }
        }
    }
}
function chooseFile(){
    abort();
    let chooseFile = document.getElementById("uploadFile");
    chooseFile.click();
}
function file_open(event){
    let file = event.currentTarget.files[0];
    let httpPoster = new XMLHttpRequest();
    let fr = new FormData();
    let tMFrame = document.getElementById("transferMessageFrame");
    let TM = document.getElementById("transferMessage");
    let Message = document.getElementById("isSuccess");
    let route = document.getElementById("route");
    let a = route.innerHTML.indexOf("/");
    let savePath;
    if(a!=-1){
        savePath=encodeURIComponent("/storage/emulated/0/"+route.innerHTML.substring(route.innerHTML.indexOf('/'),route.innerHTML.length));
    }
    else{
        savePath=encodeURIComponent("/storage/emulated/0/");
    }
    tMFrame.style.display = "block";
    fr.append("file", file);
    httpPoster.open("POST", UResourseL.hostName + "/upload?savePath="+savePath+"&fileName=" + file.name, true);
    httpPoster.send(fr);
    httpPoster.onreadystatechange = function () {
        if (httpPoster.readyState == 4 && httpPoster.status == 200) {
            let flag = httpPoster.responseText;
            let fallBackMess = JSON.parse(flag);
            if(fallBackMess.code="1") {
                TM.style.display="none";
                Message.innerHTML = "上传成功";
                refreshAF();
            }
            else {
                TM.style.display = "none";
                Message.innerHTML="上传失败";
            }
            setTimeout(function(){
                tMFrame.style.display="none";
                TM.style.display="block";
                Message.innerHTML = "上传中";
            },2500);
        }
    }
    refreshAF();
}