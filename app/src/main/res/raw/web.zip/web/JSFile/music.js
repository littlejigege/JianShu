function doResponse(JSONObject){
  var KB = 1024;
  var MB = KB*1024;
  var GB = MB*1024;
  var fileList = document.getElementById("fileList");
  if(JSONObject.mFile.length==0) fileList.innerHTML="空空如也哦";
  for(var i=0;i<JSONObject.mFile.length;i++){
    var e = document.getElementById("fileList");    //获取装载文件信息的容器
    var node1 = document.createElement("tr");//建立行单元
    var arrayNode = new Array(6);//建立6个列单元
    for(var k=0;k<arrayNode.length;k++){
      arrayNode[k] = document.createElement("td");
    }
    e.appendChild(node1);
    node1.id='tr_'+i;
    e=document.getElementById("tr_"+i);//获取指定的行单元
    for(var j=0;j<arrayNode.length;j++){//将列单元放入行单元中。
      e.appendChild(arrayNode[j]);
    }
    var imgDot = document.createElement("img");//产生img单元，用来容纳选中图片.
    imgDot.src="images/headerPicture/grayDot.png";
    imgDot.className="adjustDot";//设置img的class
    imgDot.id="row_"+i;
    imgDot.onclick=function() {//设置img的点击事件。点击进行图片的切换
      var flag=(this.getAttribute("style")===null);
      var hiddenBlock = document.getElementById("hiddenBlock");
      var selectedNum = document.getElementById("selectedNum");
      if(flag){
        this.style.backgroundImage="url('images/blueWhiteDot.png')";
        if(selectedNum.innerHTML=='') selectedNum.innerHTML='1';
        else selectedNum.innerHTML = String(1+parseInt(selectedNum.innerHTML));
        hiddenBlock.style.display = "block";
      }
      else if(flag==false){ 
         this.removeAttribute("style");
         if(selectedNum.innerHTML=='1'){
           hiddenBlock.style.display = "none";
           selectedNum.innerHTML='';
         }
         else if(selectedNum.innerHTML!='')
           selectedNum.innerHTML = String(parseInt(selectedNum.innerHTML)-1);
         var selectAll=document.getElementById("selectAll"); 
         selectAll.removeAttribute("style");//当去掉背景图片时全选按钮变为未选。
       }
    }
    var songImg = document.createElement("img");
    songImg.src="images/song.png";
    arrayNode[1].appendChild(songImg);
    //以下进行列单元内容的填充。
    arrayNode[0].appendChild(imgDot);
    //以下进行链接的设置
    var musicLink = document.createElement("a");
    let label = document.createElement("LABEL");
    label.setAttribute("for","row_"+i);
    musicLink.href=UResourseL.download+encodeURIComponent(JSONObject.mFile[i].path)+"&preview=true";
    musicLink.innerHTML=JSONObject.mFile[i].path.substring(JSONObject.mFile[i].path.lastIndexOf('/')+1,JSONObject.mFile[i].path.length);
    musicLink.className="fileLinker";
    musicLink.id="fileLinker_"+i;
    musicLink.onclick = function(event){
      event.preventDefault();
    }
    label.appendChild(musicLink);
    arrayNode[2].appendChild(label);
    arrayNode[3].innerHTML=JSONObject.mFile[i].lastModify;
    var docSizeNum = JSONObject.mFile[i].size;
    var docSizeStr;
    //以下进行比特单位的添加
    if(docSizeNum<KB){
      docSizeStr = docSizeNum.toFixed(2)+" B";
    }
    else if(docSizeNum>=KB && docSizeNum<MB){
      docSizeNum /=KB; 
      docSizeStr = docSizeNum.toFixed(2)+" KB";
    }
    else if(docSizeNum>=MB && docSizeNum<GB){
      docSizeNum /= MB;
      docSizeStr = docSizeNum.toFixed(2)+" MB";
    }
    else{
      docSizeNum /= GB;
      docSizeStr = docSizeNum.toFixed(2)+" GB";
    }
    arrayNode[4].innerHTML=docSizeStr;
    arrayNode[5].innerHTML = '音频文件';
    arrayNode[5].id="isFile_"+i;
  }
}
window.onload = function() {
   var request=new HttpRequester(UResourseL.getMusic,doResponse);//进行http请求
   request.httpRequest();
}
function refreshForMus(){
  refresh(UResourseL.getMusic,doResponse);
}