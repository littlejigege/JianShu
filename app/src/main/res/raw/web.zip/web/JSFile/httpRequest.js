function HttpRequester(URL, doResponse) {
    let loadingMessage = document.getElementById("loadingMessage");
    this.httpRequest = function () {
        var request = new XMLHttpRequest();
        var timeOut;
        timeOut = setTimeout(function () {
            request.abort();
            alert("请求超时");
        }, 10000)
        request.onreadystatechange = function () {
            if (request.readyState === 4) {
                if (request.status >= 200 && request.status <= 304) {
                    if (timeOut) clearTimeout(timeOut);
                    var response = request.responseText;
                    var JSONObject = JSON.parse(response);
                    console.log(JSONObject);
                    doResponse(JSONObject);
                }
            }
        }
        request.open("GET", URL, true);
        request.send(null);
        request.ontimeout = function (event) {
            loadingMessage.innerHTML = "";
            let span = document.createElement("span");
            span.innerHTML="加载失败";
            loadingMessage.appendChild(span);
        }
    }
}