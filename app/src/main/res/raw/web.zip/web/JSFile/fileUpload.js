window.onload =function(){
    let mainContainer = document.getElementById("transferArea");
    mainContainer.ondragover = function(event){
        event.preventDefault();
    };
    mainContainer.ondragenter = function(event){
        event.preventDefault();
    };
    mainContainer.ondragleave = function(event){
        event.preventDefault();
    };
    mainContainer.ondrop = function(event){
        event.preventDefault();
        let file = event.dataTransfer.files[0];
        let httpPoster = new XMLHttpRequest();
        let fr = new FormData();
        fr.append("file",file);
        httpPoster.open("POST",UResourseL.hostName+"/upload?savePath=/storage/emulated/0/WPS_Upload&fileName="+file.name,true);
        httpPoster.send(fr);
        httpPoster.onreadystatechange = function(){
            if(httpPoster.readyState==4 && httpPoster.status ==200){
                let flag = httpPoster.responseText;
                console.log(flag);
            }
        }
    }
}