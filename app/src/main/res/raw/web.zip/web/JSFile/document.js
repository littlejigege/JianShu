function doResponse(JSONObject) {
    var KB, MB, GB;
    KB = 1024;
    MB = KB * 1024;
    GB = MB * 1024;
    for (var i = 0; i < JSONObject.mFile.length; i++) {
        var e = document.getElementById("fileList");//获取放置文件信息的容器
        var node1 = document.createElement("tr");//创建表格的行单元
        var arrayNode = new Array(6);//创建六行的表格列单元
        for (var k = 0; k < arrayNode.length; k++) {
            arrayNode[k] = document.createElement("td");
        }
        var imgDot = document.createElement("img");//创建img单元
        imgDot.src = "images/headerPicture/grayDot.png";//设置img的src属性
        imgDot.className = "adjustDot";
        imgDot.id = "row_" + i;
        imgDot.onclick = function () {  //设置onclick事件为切换图片函数
            var flag = (this.getAttribute("style") === null);
            var hiddenBlock = document.getElementById("hiddenBlock");
            var selectedNum = document.getElementById("selectedNum");
            if (flag) {
                this.style.backgroundImage = "url('images/blueWhiteDot.png')";
                if (selectedNum.innerHTML == '') selectedNum.innerHTML = '1';
                else selectedNum.innerHTML = String(1 + parseInt(selectedNum.innerHTML));
                hiddenBlock.style.display = "block";
                console.log(hiddenBlock.style.display);
            }
            else if (flag == false) {
                this.removeAttribute("style");
                if (selectedNum.innerHTML == '1') {
                    hiddenBlock.style.display = "none";
                    selectedNum.innerHTML = '';
                }
                else if (selectedNum.innerHTML != '')
                    selectedNum.innerHTML = String(parseInt(selectedNum.innerHTML) - 1);
                var selectAll = document.getElementById("selectAll");
                selectAll.removeAttribute("style");//当去掉背景图片时全选按钮变为未选。
            }
        }
        e.appendChild(node1);
        node1.id = 'tr_' + i; //给行单元设置id
        e = document.getElementById("tr_" + i);//获取行单元
        for (var j = 0; j < arrayNode.length; j++) {//行单元中加入列单元
            e.appendChild(arrayNode[j]);
        }
        //以下依次给列单元添加内容，分别为选中图片、文件夹图片、名称、最后修改日期、大小、文件类型
        arrayNode[0].appendChild(imgDot);
        var doctype = JSONObject.mFile[i].path.substring(JSONObject.mFile[i].path.lastIndexOf('.') + 1, JSONObject.mFile[i].path.length);
        var img = document.createElement("img");
        switch (doctype) {
            case "doc":
            case "docx":
                img.src = "images/docx.png";
                break;
            case "pdf":
                img.src = "images/PDF.png";
                break;
            case "txt":
                img.src = "images/TXT.png";
                break;
            case "xls":
            case "xlsx":
                img.src = "images/xlsx.png";
                break;

        }
        arrayNode[1].appendChild(img);
        var fileLink = document.createElement("a");
        fileLink.id = "fileLinker_" + i;
        fileLink.href = UResourseL.download + encodeURIComponent(JSONObject.mFile[i].path) + "&preview=true";
        //console.log(UResourseL.hostName+encodeURIComponent(JSONObject.mFile[i].path));
        fileLink.className = "fileLinker";
        fileLink.onclick = function (event) {
            event.preventDefault();
        }
        let label = document.createElement("LABEL");
        label.setAttribute("for","row_"+i);
        label.appendChild(fileLink);
        fileLink.innerHTML = JSONObject.mFile[i].path.substring(JSONObject.mFile[i].path.lastIndexOf('/') + 1, JSONObject.mFile[i].path.length);
        arrayNode[2].appendChild(label);
        arrayNode[3].innerHTML = JSONObject.mFile[i].lastModify;
        var docSizeNum = JSONObject.mFile[i].size;//按照大小添加比特单位
        var docSizeStr;
        if (docSizeNum < KB) {
            docSizeStr = docSizeNum.toFixed(2) + " B";
        }
        else if (docSizeNum >= KB && docSizeNum < MB) {
            docSizeNum /= KB;
            docSizeStr = docSizeNum.toFixed(2) + " KB";
        }
        else if (docSizeNum >= MB && docSizeNum < GB) {
            docSizeNum /= MB;
            docSizeStr = docSizeNum.toFixed(2) + " MB";
        }
        else {
            docSizeNum /= GB;
            docSizeStr = docSizeNum.toFixed(2) + " GB";
        }
        arrayNode[4].innerHTML = docSizeStr;
        arrayNode[5].innerHTML = JSONObject.mFile[i].isDirectory ? '文件夹' : '文件';
        if (JSONObject.mFile[i].isDirectory) arrayNode[5].id = "isDirectory_" + i;
        else arrayNode[5].id = "isFile_" + i;
    }
}

window.onload = function () {
    var request = new HttpRequester(UResourseL.getDocument, doResponse);
    request.httpRequest();
}
function refreshForDoc(){
    refresh(UResourseL.getDocument,doResponse);
}