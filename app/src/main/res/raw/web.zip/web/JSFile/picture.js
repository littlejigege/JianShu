window.onload = function () {
    var request = new HttpRequester(UResourseL.getPhotoSet, buildPhotoList);
    request.httpRequest();
}
var flag =true;
function buildPhotoList(JSONObject) {
    var data = JSONObject.mFile;
    let loading = document.getElementById("loading");
    loading.style.display = "block";
    for (var i = 0; i < data.length; i++) {
        var url1 = data[i].path;
        var name = "<br />" + data[i].name;
        var httpRequester = new HttpRequester(UResourseL.getPhoto + encodeURIComponent(data[i].path), getThumbNail);
        setTimeout(httpRequester.httpRequest(), 2000);
    }
}

function getThumbNail(JSONObject) {
    let picData = JSONObject.mFile;//获取图片的信息
    let img = document.createElement("img");                    //创建图片容器
    let photoList = document.getElementById("photoList");       //获取sidebar
    let link = document.createElement("a");
    let picture;                                                //用于存储JSON数组中文件的后缀名。
    let picPath;                                                //用于存储数组中第一个是图片文件的路径
    let rootPath;                                               //用于存储此图集的根目录
    let listPicContainer = document.createElement("div");       //用于存放左侧图片列表中一个项的容器
    let name;                                                   //用于显示图集的名称
    for (let i = 0; i < picData.length; i++) {
        picture = picData[i].path.substring(picData[i].path.lastIndexOf('.') + 1, picData[i].path.length);
        if (picture === "jpg" || picture === "jpeg" || picture === "png" || picture === "gif" || picture === "webp") {
            picPath = picData[i].path;
            break;
        }
    }
    rootPath = picData[0].path.substring(0, picData[0].path.lastIndexOf("/"));
    name = document.createElement("span");
    name.innerHTML = rootPath.substring(rootPath.lastIndexOf("/") + 1, rootPath.length);
    name.className = "setNameStyle";
    listPicContainer.className = "listPhotoUnit";
    img.src = UResourseL.getThumbNail + encodeURIComponent(picPath) + "&type=photo";
    console.log(img.src);
    img.className = "listPicStyle";
    link.appendChild(img);
    link.id = "a_" + getThumbNail.counter;
    link.className = "photoListLink";
    link.href = UResourseL.getPhoto + rootPath;
    link.onclick = function (event) {
        event.preventDefault();
        let loading = document.getElementById("loading");
        loading.style.display = "block";
        let hiddenBlock = document.getElementById("hiddenBlock");
        let selectedNum = document.getElementById("selectedNum");
        hiddenBlock.style.display = "none";
        selectedNum.innerHTML = '';
        let http = new HttpRequester(this.href, showAllPicInOneSet);
        http.httpRequest();
    }
    if(flag===true) {
        link.click();
        flag=false;
    }
    listPicContainer.appendChild(link);
    listPicContainer.appendChild(name);
    photoList.appendChild(listPicContainer);
    loading.style.display = "none";
}

function showAllPicInOneSet(JSONObject) {
    let allPic = JSONObject.mFile;//获取一个文件夹中的所有图片的信息
    let j = 0;
    let loading = document.getElementById("loading");
    loading.style.display = "block";
    let SPContainer = document.getElementById("SPContainer");//获取用于展示图片的容器
    SPContainer.innerHTML = "";//清空容器中的内容
    // noinspection JSAnnotator
    for (let i = 0; i < allPic.length; i++) {//处理图片
        let pic = document.createElement("img");
        let picContainer = document.createElement("div");
        picContainer.className = "showPicture";
        pic.src = UResourseL.getThumbNail + encodeURIComponent(allPic[i].path) + "&type=photo";
        pic.className = "picStyle";
        let selectedDot = document.createElement("img");
        selectedDot.src = "images/headerPicture/grayDot.png";
        selectedDot.className = "adjustDot";
        selectedDot.id = "img_" + String(i);
        selectedDot.onclick = function () {//设置img的点击事件。点击进行图片的切换
            var flag = (this.getAttribute("style") === null);
            var hiddenBlock = document.getElementById("hiddenBlock");
            var selectedNum = document.getElementById("selectedNum");
            if (flag) {
                this.style.backgroundImage = "url('images/blueWhiteDot.png')";
                if (selectedNum.innerHTML == '') selectedNum.innerHTML = '1';
                else selectedNum.innerHTML = String(1 + parseInt(selectedNum.innerHTML));
                hiddenBlock.style.display = "block";
            }
            else if (flag == false) {
                this.removeAttribute("style");
                if (selectedNum.innerHTML == '1') {
                    hiddenBlock.style.display = "none";
                    selectedNum.innerHTML = '';
                }
                else if (selectedNum.innerHTML != '')
                    selectedNum.innerHTML = String(parseInt(selectedNum.innerHTML) - 1);
                var selectAll = document.getElementById("selectAll");
                selectAll.removeAttribute("style");//当去掉背景图片时全选按钮变为未选。
            }
        }
        let picLinker = document.createElement("a");
        picLinker.id = "picLinker_" + String(i);
        picLinker.appendChild(pic);
        picContainer.appendChild(selectedDot);
        picContainer.appendChild(picLinker);
        picContainer.id = "div_" + String(i);
        picLinker.className = "PLStyle";
        picLinker.href = UResourseL.download + encodeURIComponent(allPic[i].path)+"&preview=true";
        SPContainer.appendChild(picContainer);
    }
    loading.style.display = "none";
}

function changeImg() {//用于全选按钮的onclick
    var selectAll = document.getElementById("selectAll");
    var notChange = (selectAll.getAttribute("style") === null);
    var picGroup = document.getElementsByClassName("adjustDot");
    var selectedNum = document.getElementById("selectedNum");
    var hiddenBlock = document.getElementById("hiddenBlock");
    if (notChange) {//修改所有的选中图片为选中或者不选中
        selectAll.style.backgroundImage = "url('images/blueWhiteDot.png')";
        for (let i = 0; i < picGroup.length; i++) {
            picGroup[i].style.backgroundImage = "url('images/blueWhiteDot.png')";
        }
        selectedNum.innerHTML = '' + picGroup.length;
        hiddenBlock.style.display = "block";
    }
    else if (!notChange) {
        selectAll.removeAttribute("style");
        for (var i = 0; i < picGroup.length; i++) {
            if (picGroup[i].getAttribute("style") !== null) {
                picGroup[i].removeAttribute("style");
            }
        }
        hiddenBlock.style.display = "none";
        selectedNum.innerHTML = '';
    }
}

function blockClose() {
    var hBlock = document.getElementById("hiddenBlock");
    var selectedNumber = document.getElementById("selectedNum");
    hBlock.style.display = "none";
}

function blockDelete() {
    let selectedGroup = document.getElementsByClassName("SPSelectedDot");
    let totalURL = "";
    let selectedNum = document.getElementById("selectedNum");
    let hiddenBlock = document.getElementById("hiddenBlock");
    let SPContainer, div, picLinker;
    let num;                                //判断是哪个被删除了
    SPContainer = document.getElementById("SPContainer");
    for (let i = 0; i < selectedGroup.length; i++) {
        if (selectedGroup[i].getAttribute("style") !== null) {
            num = selectedGroup[i].id.substring(selectedGroup[i].id.indexOf('_') + 1, selectedGroup[i].id.length);
            div = document.getElementById("div_" + num);
            picLinker = document.getElementById("picLinker_" + num);
            totalURL += encodeURIComponent(picLinker.href.substring(picLinker.href.indexOf('/storage'), picLinker.href.length)) + '|';
            SPContainer.removeChild(div);
            i--;
        }
    }
    totalURL = totalURL.substring(0, totalURL.length - 1);
    console.log(totalURL);
    let requester = new HttpRequester(UResourseL.delete + totalURL, function (JSONObject) {
        console.log("success");
    });
    requester.httpRequest();
    selectedNum.innerHTML = "";
    hiddenBlock.style.display = "none";
}

function downloadPicture() {
    let selectedGroup = document.getElementsByClassName("adjustDot");
    let totalURL = "";
    let picLinker;
    let num;                                //判断哪几个需要下载
    let hiddenBlock = document.getElementById("hiddenBlock");
    let selectedNum = document.getElementById("selectedNum");
    for (let i = 0; i < selectedGroup.length; i++) {
        if(selectedGroup.id!=="selectAll") {
            if (selectedGroup[i].getAttribute("style") !== null) {
                num = selectedGroup[i].id.substring(selectedGroup[i].id.indexOf('_') + 1, selectedGroup[i].id.length);
                picLinker = document.getElementById("picLinker_" + num);
                totalURL += picLinker.href.substring(picLinker.href.indexOf('=')+1, picLinker.href.lastIndexOf('&')) + '|';
                selectedGroup[i].removeAttribute("style");
            }
        }
    }
    totalURL = totalURL.substring(0, totalURL.length - 1);
    let downloadLink = document.createElement("a");
    downloadLink.href = UResourseL.download + totalURL;
    console.log(downloadLink.href);
    $(document.body).append(downloadLink);
    downloadLink.click();
    document.body.removeChild(document.body.lastChild);
    hiddenBlock.style.display = "none";
    selectedNum.innerHTML = '';
}

function refreshPic() {
    let picList = document.getElementById("photoList");
    picList.innerHTML = "";
    let loading = document.getElementById("loading");
    loading.style.display = "block";
    var request = new HttpRequester(UResourseL.getPhotoSet, buildPhotoList);
    request.httpRequest();
}
