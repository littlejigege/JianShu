/*$("#searchContent").bind("keypress",function(event){
    if(event.keyCode=="13"){
        $("#searchBtnFrame").click();
    }
})*/
function changeImg() {//用于全选按钮的onclick
    var selectAll = document.getElementById("selectAll");
    var notChange = (selectAll.getAttribute("style") === null);
    console.log(notChange);
    var picGroup = document.getElementsByClassName("adjustDot");
    var selectedNum = document.getElementById("selectedNum");
    var hiddenBlock = document.getElementById("hiddenBlock");
    if (notChange) {//修改所有的选中图片为选中或者不选中
        for (let i = 0; i < picGroup.length; i++) {
            picGroup[i].style.backgroundImage = "url('images/blueWhiteDot.png')";
        }
        selectedNum.innerHTML = '' + picGroup.length - 1;
        hiddenBlock.style.display = "block";
    }
    else if (!notChange) {
        for (var i = 0; i < picGroup.length; i++) {
            if (picGroup[i].getAttribute("style") !== null) {
                picGroup[i].removeAttribute("style");
            }
        }
        hiddenBlock.style.display = "none";
        selectedNum.innerHTML = '';
    }
}

function blockClose() {
    var hBlock = document.getElementById("hiddenBlock");
    var selectedNumber = document.getElementById("selectedNum");
    hBlock.style.display = "none";
}

function blockDelete() {
    let selectedGroup = document.getElementsByClassName("adjustDot");
    let totalURL = "";
    let fileList = document.getElementById("fileList");
    let selectedNum = document.getElementById("selectedNum");
    let hiddenBlock = document.getElementById("hiddenBlock");
    for (let i = 0; i < selectedGroup.length; i++) {
        if (selectedGroup[i].id !== "selectAll") {
            if (selectedGroup[i].getAttribute("style") !== null) {
                let row = selectedGroup[i].id.substring(selectedGroup[i].id.indexOf('_') + 1, selectedGroup[i].id.length);//获取行数
                console.log(row);
                let fileLinker = document.getElementById("fileLinker_" + row);//获取对应行的文件链接
                let rowToRemove = document.getElementById("tr_" + row);
                console.log(fileLinker);
                let isDirectory = document.getElementById("isDirectory_" + row);
                if (isDirectory===null) {
                    totalURL += fileLinker.href.substring(fileLinker.href.indexOf('=') + 1, fileLinker.href.lastIndexOf('&')) + '|';
                }
                else {
                    totalURL += fileLinker.href.substring(fileLinker.href.indexOf("=") + 1, fileLinker.href.length) + '|';
                }
                fileList.removeChild(rowToRemove);
                i--;//删除后length减去了1，发生改变，因此i也必须减一
            }
        }
    }
    selectedNum.innerHTML = "";
    hiddenBlock.style.display="none";
    totalURL = totalURL.substring(0, totalURL.length - 1);
    var httpR = new HttpRequester(UResourseL.delete + totalURL, function (JSONObject) {
        console.log("success");
    });
    httpR.httpRequest();
}

function refresh(urlForRefresh, refreshFunction) {
    var fileList = document.getElementById("fileList");
    fileList.innerHTML = "";
    for (var i = 0; i < 6; i++) {
        var col = document.createElement("col");
        col.className = "space" + String(i + 1);
        fileList.appendChild(col);
    }
    var requester = new HttpRequester(urlForRefresh, refreshFunction);
    requester.httpRequest();
}

function search() {
    var table = document.getElementById("fileList");
    var searchContent = document.getElementById("searchContent");
    var str1 = searchContent.value.toUpperCase();
    if (str1 === '') return;
    var rows = table.rows;
    var searchResult = [];
    var j = 0;
    for (var i = 0; i < rows.length; i++) {
        var str2 = rows[i].cells[2].firstChild.innerHTML;
        str2 = str2.toUpperCase();
        if (str1 == str2) {
            searchResult[j] = rows[i];
            j++;
        }
        else {
            for (var l = 0; l < strArray.length; l++)
                if (str2.search(str1) !== -1) {
                    searchResult[j] = rows[i];
                    j++;
                }
        }
    }
    var fileList = document.getElementById("fileList");
    fileList.innerHTML = "";
    if (searchResult.length !== 0) {
        for (var k = 0; k < 6; k++) {
            var col = document.createElement("col");
            col.className = "space" + String(k + 1);
            fileList.appendChild(col);
        }
        for (var z = 0; z < searchResult.length; z++) {
            fileList.appendChild(searchResult[z]);
        }
    }
    else fileList.innerHTML = "无结果";
}