var UResourseL = {};
UResourseL.hostName = "http://"+window.location.host;
UResourseL.getAllFile = UResourseL.hostName+"/find?path=storage/emulated/0/";
UResourseL.getPhotoSet = UResourseL.hostName+"/getMedia?type=photoDir";
UResourseL.getMusic = UResourseL.hostName+"/getMedia?type=music";
UResourseL.getDocument = UResourseL.hostName+"/getMedia?type=document";
UResourseL.getDeviceInfo = UResourseL.hostName+"/getDeviceInfo";
UResourseL.getPhoto=UResourseL.hostName+"/getMedia?type=photo&path=";
UResourseL.getThumbNail=UResourseL.hostName+"/getThumbnail?path=";
UResourseL.getFile = UResourseL.hostName+"/find?path=";
UResourseL.download = UResourseL.hostName+"/download?path=";
UResourseL.delete = UResourseL.hostName+"/file?operation=delete&path=";
UResourseL.getApp = UResourseL.hostName+"/getApp";
UResourseL.createNewFolder = UResourseL.hostName+"/file?operation=create&path=";

